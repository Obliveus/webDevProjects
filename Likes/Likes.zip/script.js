let likeCount1 = document.querySelector("likeCount1");
let likeCount2 = document.querySelector("likeCount2");
let likeCount3 = document.querySelector("likeCount3");
let add1 = 0;
let add2 = 0;
let add3 = 0;

function likeBtn1() {
    add1++
    document.querySelector("#likeCount1").innerHTML = likeCount1 + add1;
}

function likeBtn2() {
    add2++
    document.querySelector("#likeCount2").innerHTML = likeCount2 + add2;
}

function likeBtn3() {
    add3++
    document.querySelector("#likeCount3").innerHTML = likeCount3 + add3;
}