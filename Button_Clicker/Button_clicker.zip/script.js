function LogOut() {
    document.getElementById("btn").innerHTML = "Logout";
}

function hidebtn() {
    let hideDef = document.getElementById("addDefine");
    hideDef.style.display = "none";
}